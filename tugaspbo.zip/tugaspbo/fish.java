import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class fish here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class fish extends Actor
{
    private int speed = 2; // Kecepatan pergerakan objek
    private int direction = Greenfoot.getRandomNumber(360);
    /**
     * Act - do whatever the fish wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        double radians = Math.toRadians(direction);
        int deltaX = (int) (Math.cos(radians) * speed);
        int deltaY = (int) (Math.sin(radians) * speed);
        setLocation(getX() + deltaX, getY() + deltaY);

        // Jika objek mencapai tepi layar, ubah arahnya
        if (getX() <= 0 || getX() >= getWorld().getWidth() - 1 ||
            getY() <= 0 || getY() >= getWorld().getHeight() - 1) {
            direction = Greenfoot.getRandomNumber(360);
        }
    }
}
