import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1);
        Random random = new Random();
        Boolean isRunning = false;
        for (int i = 0; i < 9; i++) {
            int x = random.nextInt(this.getWidth() - 1);
            int y = random.nextInt(this.getHeight() - 1);
            fish Ikan1 = new fish();
            Ikan1.setRotation(75 * random.nextInt(2)); // Menghasilkan 0 atau 75
            addObject(Ikan1, x, y);
        }
    }
}
